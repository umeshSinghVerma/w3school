package com.example.thread.post.service;

import java.util.List;

import com.example.thread.post.model.Post;

public interface PostService {

    public List<Post> getAllPosts();

    public Post getPostById(Long postId);

    public boolean deletePostById(Long postId);

    // public void addPost(Post post);
}