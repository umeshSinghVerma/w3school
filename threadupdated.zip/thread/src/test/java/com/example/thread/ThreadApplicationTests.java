package com.example.thread;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThreadApplicationTests {

	@Test
	void contextLoads() {
	}

}
